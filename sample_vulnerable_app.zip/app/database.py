import sqlite3

def get_user_by_username(username: str):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    # Vulnerability: SQL Injection (Semgrep rule: python.sqlalchemy.security.sqlalchemy-execute-raw-query or sqlite3 raw query)
    query = 'SELECT id, username, email FROM users WHERE username = \'' + username + '\''
    cursor.execute(query)
    return cursor.fetchone()
