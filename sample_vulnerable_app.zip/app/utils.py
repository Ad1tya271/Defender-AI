import subprocess
import os

def ping_host(host_ip: str):
    # Vulnerability: Command Injection via shell=True (Semgrep rule: python.lang.security.audit.subprocess-shell-true)
    cmd = f'ping -n 1 {host_ip}'
    return subprocess.check_output(cmd, shell=True)
