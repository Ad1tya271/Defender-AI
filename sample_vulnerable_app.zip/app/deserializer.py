import pickle
import yaml

def load_user_session(raw_data: bytes):
    # Vulnerability: Insecure Deserialization via pickle (Semgrep rule: python.lang.security.deserialization.pickle)
    return pickle.loads(raw_data)

def load_custom_config(yaml_string: str):
    # Vulnerability: Insecure YAML loading (Semgrep rule: python.lang.security.deserialization.avoid-pyyaml-load)
    return yaml.load(yaml_string, Loader=yaml.Loader)
