# Vulnerability: Hardcoded High-Entropy Secret / API Key (Semgrep generic secret detection)
AWS_ACCESS_KEY_ID = 'AKIAIOSFODNN7EXAMPLE'
AWS_SECRET_ACCESS_KEY = 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
JWT_SECRET_KEY = 'super_secret_hardcoded_jwt_key_12345'
